# 📚 Get Papers List

A command-line Python tool to fetch research papers from **PubMed** and filter them to include only those with at least one **non-academic author** — like someone from a pharma or biotech company.

---

## 📁 Project Structure

```
get-papers/
├── src/
│   └── get_papers/
│       ├── cli.py           # Typer CLI interface
│       ├── main.py          # Orchestrates the workflow
│       ├── pubmed_api.py    # Fetches data from PubMed (Entrez API)
│       ├── filtering.py     # Filters authors by academic vs non-academic
│       ├── csv_writer.py    # Saves results to CSV
│       └── __init__.py
├── tests/                   # (optional) testing files
├── pyproject.toml           # Poetry config
├── README.md                # You're reading it
└── report.pdf               # Project summary report
```

---

## ⚙️ Installation

1. Make sure Python 3.9+ is installed
2. Install Poetry (https://python-poetry.org/docs/#installation)
3. Clone this repo and run:

```bash
poetry install
```

---

## 🚀 Usage

```bash
poetry run get-papers-list "your query" --file output.csv --debug
```

### Example:

```bash
poetry run get-papers-list "mRNA vaccine" --file results.csv --debug
```

### Options:
- `--file` or `-f`: Save output to a CSV file (optional, else prints to console)
- `--debug` or `-d`: Show extra logs
- `--help` or `-h`: Show help info

---

## 🧠 How Filtering Works

The tool analyzes the **affiliations of each author** and detects if any are non-academic.  
It skips authors from:
- universities
- hospitals
- institutes
- `.edu` domains

It includes authors from:
- companies (e.g., Pfizer, Genentech)
- private labs (e.g., Biotech Inc., Diagnostics Ltd.)
- independent or commercial healthcare firms

---

## 🛠 Tools & Libraries Used

- [`Biopython`](https://biopython.org/wiki/Entrez) → For accessing PubMed Entrez API
- [`Typer`](https://typer.tiangolo.com/) → To build the command-line interface
- [`pandas`](https://pandas.pydata.org/) → For writing CSV files
- [`Poetry`](https://python-poetry.org/) → For dependency management
- [`ChatGPT`](https://chat.openai.com/) → Used for technical guidance and structure ideas

---

## 🤖 LLM Tools Used

This project was built with support from **ChatGPT (OpenAI)** to:
- Structure the overall CLI tool
- Design the PubMed filtering logic
- Refine heuristic methods for identifying non-academic affiliations
- Generate README, report, and code explanations

Link to full LLM conversation used during development:  
👉 [ChatGPT Conversation Transcript](   )




## 🧪 Testing & Output

Tested with queries like `"covid vaccine"` and `"gene therapy"`.  
The tool successfully includes only papers with at least one **non-academic** author.  
Missing emails or affiliations are safely handled without crashing.

---

## ✍️ Author

**Dhanushkumar V**

---

## 📝 License

This project is shared for educational and demo purposes.